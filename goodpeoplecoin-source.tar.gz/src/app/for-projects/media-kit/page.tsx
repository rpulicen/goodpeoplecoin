import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Download, Users, TrendingUp, Globe, BarChart3 } from 'lucide-react'

export default function MediaKitPage() {
  const stats = [
    { icon: Users, label: 'Monthly Active Users', value: '100K+' },
    { icon: TrendingUp, label: 'Growth Rate', value: '25% MoM' },
    { icon: Globe, label: 'Countries Reached', value: '120+' },
    { icon: BarChart3, label: 'Projects Tracked', value: '150+' },
  ]

  const demographics = [
    { label: 'Crypto Donors', value: '40%' },
    { label: 'Project Founders', value: '25%' },
    { label: 'Investors & VCs', value: '20%' },
    { label: 'Researchers', value: '15%' },
  ]

  const assets = [
    {
      title: 'Logo Package',
      description: 'PNG, SVG, and EPS formats in various color schemes',
      size: '2.5 MB',
    },
    {
      title: 'Brand Guidelines',
      description: 'Color palette, typography, and usage guidelines',
      size: '1.8 MB',
    },
    {
      title: 'Media Kit PDF',
      description: 'Complete overview with stats and partnership opportunities',
      size: '4.2 MB',
    },
    {
      title: 'Press Images',
      description: 'High-resolution screenshots and product images',
      size: '8.7 MB',
    },
  ]

  return (
    <div className="flex flex-col">
      <section className="border-b border-border/40 bg-gradient-radial">
        <div className="container py-16 md:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              Media <span className="text-neon-green">Kit</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              Everything you need to know about GoodPeopleCoin's audience, reach, and partnership opportunities.
            </p>
          </div>
        </div>
      </section>

      {/* Key Stats */}
      <section className="container py-16 md:py-24">
        <div className="mx-auto max-w-2xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Platform Statistics
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Current metrics and audience insights.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.label}>
                <CardContent className="p-6 text-center">
                  <Icon className="h-8 w-8 text-neon-green mx-auto mb-4" />
                  <div className="text-3xl font-bold text-neon-green mb-2">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.label}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>

      {/* Audience Demographics */}
      <section className="border-t border-border/40 bg-gradient-radial">
        <div className="container py-16 md:py-24">
          <div className="mx-auto max-w-2xl text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Audience Demographics
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Who uses GoodPeopleCoin.
            </p>
          </div>

          <div className="mx-auto max-w-2xl">
            <Card>
              <CardContent className="p-8">
                <div className="space-y-6">
                  {demographics.map((demo) => (
                    <div key={demo.label}>
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">{demo.label}</span>
                        <span className="text-neon-green font-bold">{demo.value}</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-neon-green transition-all"
                          style={{ width: demo.value }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Download Assets */}
      <section className="container py-16 md:py-24">
        <div className="mx-auto max-w-2xl text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Download Assets
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Brand assets and media resources for partners and press.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {assets.map((asset) => (
            <Card key={asset.title}>
              <CardHeader>
                <CardTitle className="text-xl">{asset.title}</CardTitle>
                <CardDescription className="text-base pt-2">
                  {asset.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{asset.size}</span>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Card className="inline-block p-6">
            <CardDescription className="mb-4">
              Need custom assets or have media inquiries?
            </CardDescription>
            <Button asChild size="lg">
              <a href="mailto:press@goodpeoplecoin.com">
                Contact Press Team
              </a>
            </Button>
          </Card>
        </div>
      </section>

      {/* About */}
      <section className="border-t border-border/40 bg-gradient-radial">
        <div className="container py-16 md:py-24">
          <div className="mx-auto max-w-3xl">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl text-center mb-8">
              About GoodPeopleCoin
            </h2>
            <Card>
              <CardContent className="p-8 space-y-4 text-muted-foreground">
                <p>
                  GoodPeopleCoin is the leading platform for transparent crypto charity rankings and verified impact projects. We help donors discover and evaluate charitable crypto projects using on-chain data verification and comprehensive transparency scoring.
                </p>
                <p>
                  Founded in 2024, our mission is to bring accountability and transparency to crypto philanthropy by providing donors with the data they need to make informed giving decisions.
                </p>
                <p>
                  Our platform tracks over 150 crypto charity projects, analyzes $50M+ in donation flows, and serves 100K+ monthly users who are committed to transparent and impactful charitable giving.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
