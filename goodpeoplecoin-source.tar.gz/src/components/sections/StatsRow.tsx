export function StatsRow() {
  const stats = [
    {
      label: 'Projects Tracked',
      value: '150+',
    },
    {
      label: 'On-Chain Verification',
      value: '100%',
    },
    {
      label: 'Total Donations Analyzed',
      value: '$50M+',
    },
    {
      label: 'Monthly Users',
      value: '10K+',
    },
  ]

  return (
    <div className="border-y border-border/40 bg-gradient-radial">
      <div className="container py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl font-bold text-neon-green md:text-4xl">
                {stat.value}
              </div>
              <div className="mt-2 text-sm text-muted-foreground">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
