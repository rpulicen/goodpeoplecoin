export const analyticsConfig = {
  gtm: {
    id: 'GTM-XXXXXX',
  },
  ga4: {
    measurementId: 'G-XXXXXXX',
  },
  googleAds: {
    conversionId: 'AW-XXXXXXX',
  },
} as const
